var config = {
   apiKey: "AIzaSyCnuAZzFvkT-FSRxB5Vk67JM6FU9wZLYMQ",
   authDomain: "share-b7589.firebaseapp.com",
   databaseURL: "https://share-b7589.firebaseio.com",
   projectId: "share-b7589",
   storageBucket: "share-b7589.appspot.com",
   messagingSenderId: "323469467975"
 };
 firebase.initializeApp(config); 
